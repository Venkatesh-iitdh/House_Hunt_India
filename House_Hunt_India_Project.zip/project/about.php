<?php  

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<!-- about section starts  -->

<section class="about">

   <div class="row">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>
      <div class="content">
         <h3>why choose us?</h3>
         <p>At HouseHuntIndia, we are passionate about turning your real estate dreams into reality. With years of experience in the industry, we specialize in providing personalized services that cater to your unique needs—whether you're buying, selling, renting. We understand that finding the perfect home or property is more than just a transaction; it's about making lasting memories and securing your future.</p>
         <a href="contact.html" class="inline-btn">contact us</a>
      </div>
   </div>

</section>

<!-- about section ends -->

<!-- steps section starts  -->

<section class="steps">

   <h1 class="heading">3 simple steps</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/step-1.png" alt="">
         <h3>search property</h3>
         <p>Browse and filter properties for rent or sale. Find your ideal home or investment by selecting criteria like location, price, and property type..</p>
      </div>

      <div class="box">
         <img src="images/step-2.png" alt="">
         <h3>Sell/Rent property</h3>
         <p>Easily list your property for sale or rent. Connect with potential buyers or tenants by showcasing your property to a wide audience..</p>
      </div>

      <div class="box">
         <img src="images/step-3.png" alt="">
         <h3>Contact owner</h3>
         <p>Premium users can book appointments with property owners, view listings, and chat directly to get more information and schedule viewings..</p>
      </div>

   </div>

</section>

<!-- steps section ends -->

<!-- review section starts  -->



<!-- review section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>