<?php
use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase
{
    protected $conn;  // Mocked database connection

    protected function setUp(): void
    {
        // Mock the PDO connection
        $this->conn = $this->getMockBuilder(PDO::class)
            ->disableOriginalConstructor()
            ->getMock();
    }

    // Test for successful login with matching email and password
    public function testLoginSuccess()
    {
        // Test data
        $email = "user@example.com";
        $password = "password123";
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Mocking PDO statement behavior for `prepare`, `execute`, and `fetch`
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->expects($this->once())
            ->method('execute')
            ->with([$email])
            ->willReturn(true);
        $stmt->expects($this->once())
            ->method('fetch')
            ->willReturn(['email' => $email, 'password' => $hashed_password]);

        // Set up `prepare` to return the mocked statement
        $this->conn->expects($this->once())
            ->method('prepare')
            ->willReturn($stmt);

        // Simulate calling login function and asserting success
        $result = $this->performLogin($email, $password);
        $this->assertTrue($result, "Login should succeed with correct credentials.");
    }

    // Test for failed login due to incorrect password
    public function testLoginFailure()
    {
        // Test data
        $email = "user@example.com";
        $password = "password123";
        $incorrect_password = "wrongpassword";
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Mocking PDO statement behavior for `prepare`, `execute`, and `fetch`
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->expects($this->once())
            ->method('execute')
            ->with([$email])
            ->willReturn(true);
        $stmt->expects($this->once())
            ->method('fetch')
            ->willReturn(['email' => $email, 'password' => $hashed_password]);

        // Set up `prepare` to return the mocked statement
        $this->conn->expects($this->once())
            ->method('prepare')
            ->willReturn($stmt);

        // Simulate calling login function with incorrect password
        $result = $this->performLogin($email, $incorrect_password);
        $this->assertFalse($result, "Login should fail with incorrect password.");
    }

    // Helper function to simulate login process
    private function performLogin($email, $password)
    {
        // Assuming the login logic is implemented in a function, e.g., `login`
        if (isset($this->conn)) {
            // Sample login logic
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            // Verifying password
            if ($user && password_verify($password, $user['password'])) {
                return true;
            }
        }
        return false;
    }
}
