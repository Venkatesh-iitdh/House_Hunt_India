<?php
use PHPUnit\Framework\TestCase;

class postapropertyTest extends TestCase
{
    protected $conn;

    protected function setUp(): void
    {
        $this->conn = $this->getMockBuilder(PDO::class)
            ->disableOriginalConstructor()
            ->getMock();
    }

    public function testLoginSuccess()
    {
        $email = "user@example.com";
        $password = "password123";
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $this->createMock(PDOStatement::class);
        $stmt->expects($this->once())
            ->method('execute')
            ->with([$email])
            ->willReturn(true);
        $stmt->expects($this->once())
            ->method('fetch')
            ->willReturn(['email' => $email, 'password' => $hashed_password]);

        $this->conn->expects($this->once())
            ->method('prepare')
            ->willReturn($stmt);

        $result = $this->performLogin($email, $password);
        $this->assertTrue($result, "Login should succeed with correct credentials.");
    }

    public function testLoginFailureIncorrectPassword()
    {
        $email = "user@example.com";
        $incorrect_password = "wrongpassword";
        $hashed_password = password_hash("password123", PASSWORD_DEFAULT);

        $stmt = $this->createMock(PDOStatement::class);
        $stmt->expects($this->once())
            ->method('execute')
            ->with([$email])
            ->willReturn(true);
        $stmt->expects($this->once())
            ->method('fetch')
            ->willReturn(['email' => $email, 'password' => $hashed_password]);

        $this->conn->expects($this->once())
            ->method('prepare')
            ->willReturn($stmt);

        $result = $this->performLogin($email, $incorrect_password);
        $this->assertFalse($result, "Login should fail with incorrect password.");
    }

    public function testLoginFailureEmailNotFound()
    {
        $email = "nonexistent@example.com";
        $password = "password123";

        $stmt = $this->createMock(PDOStatement::class);
        $stmt->expects($this->once())
            ->method('execute')
            ->with([$email])
            ->willReturn(true);
        $stmt->expects($this->once())
            ->method('fetch')
            ->willReturn(false);

        $this->conn->expects($this->once())
            ->method('prepare')
            ->willReturn($stmt);

        $result = $this->performLogin($email, $password);
        $this->assertFalse($result, "Login should fail if the email does not exist.");
    }

    private function performLogin($email, $password)
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            return true;
        }
        return false;
    }
}
