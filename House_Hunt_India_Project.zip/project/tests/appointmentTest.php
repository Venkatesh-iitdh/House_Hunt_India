<?php
use PHPUnit\Framework\TestCase;

class appointmentTest extends TestCase
{
    private $conn;
    private $email;
    private $password;
    private $hashedPassword;

    protected function setUp(): void
    {
        // Set up mock connection and default test data
        $this->conn = $this->createMock(PDO::class);
        $this->email = "user@example.com";
        $this->password = "password123";
        $this->hashedPassword = password_hash($this->password, PASSWORD_DEFAULT);
    }

    // Helper function to simulate the login process
    private function performLogin($email, $password)
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
        if ($stmt->execute([$email])) {
            $user = $stmt->fetch();
            if ($user && password_verify($password, $user['password'])) {
                return true;
            }
        }
        return false;
    }

    private function setupMockStatement($email, $hashedPassword, $exists = true)
    {
        // Create mock statement
        $stmt = $this->createMock(PDOStatement::class);

        // Mock the `execute` and `fetch` methods
        $stmt->method('execute')
            ->with([$email])
            ->willReturn(true);
        
        // Return user data if `exists` is true
        $stmt->method('fetch')
            ->willReturn($exists ? ['email' => $email, 'password' => $hashedPassword] : false);

        // Mock the connection's prepare method to return this statement
        $this->conn->expects($this->once())
            ->method('prepare')
            ->willReturn($stmt);
    }

    public function testSuccessfulLogin()
    {
        $this->setupMockStatement($this->email, $this->hashedPassword);

        $result = $this->performLogin($this->email, $this->password);
        $this->assertTrue($result, "Login should succeed with correct email and password.");
    }

    public function testFailedLoginWithIncorrectPassword()
    {
        $this->setupMockStatement($this->email, $this->hashedPassword);

        $result = $this->performLogin($this->email, "wrongpassword");
        $this->assertFalse($result, "Login should fail with incorrect password.");
    }

    public function testFailedLoginWithNonExistentEmail()
    {
        $this->setupMockStatement("nonexistent@example.com", "", false);

        $result = $this->performLogin("nonexistent@example.com", $this->password);
        $this->assertFalse($result, "Login should fail if the email does not exist.");
    }

    public function testFailedLoginWithEmptyEmail()
    {
        $this->setupMockStatement("", "", false);

        $result = $this->performLogin("", $this->password);
        $this->assertFalse($result, "Login should fail with empty email.");
    }

    public function testFailedLoginWithEmptyPassword()
    {
        $this->setupMockStatement($this->email, $this->hashedPassword);

        $result = $this->performLogin($this->email, "");
        $this->assertFalse($result, "Login should fail with empty password.");
    }

    public function testFailedLoginWithDatabaseError()
    {
        // Create a mock statement that will fail on execute
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->expects($this->once())
            ->method('execute')
            ->willReturn(false);

        $this->conn->expects($this->once())
            ->method('prepare')
            ->willReturn($stmt);

        $result = $this->performLogin($this->email, $this->password);
        $this->assertFalse($result, "Login should fail if database query execution fails.");
    }
}
