<?php
// login.php

// Include the database connection file
include 'components/connect.php'; 

// Initialize an empty warning message array
$warning_msg = [];

if (isset($_POST['submit'])) {
    // Get form input
    $email = $_POST['email'];
    $password = $_POST['pass'];

    // Sanitize and hash the password
    $email = filter_var($email, FILTER_SANITIZE_STRING);
    $password = sha1($password);
    $password = filter_var($password, FILTER_SANITIZE_STRING);

    // Prepare and execute the query to check user credentials
    $select_users = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ? LIMIT 1");
    $select_users->execute([$email, $password]);
    $row = $select_users->fetch(PDO::FETCH_ASSOC);

    // If a matching user is found, log the user in
    if ($select_users->rowCount() > 0) {
        // Set a cookie for the user ID to remember the user
        setcookie('user_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
        // Redirect to home page
        header('Location: home.php');
        exit;  // Stop further execution to prevent form resubmission
    } else {
        // If no matching user found, display an error message
        $warning_msg[] = 'Incorrect username or password!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- Font Awesome CDN for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <!-- Custom CSS link -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- Login form section starts -->
<section class="form-container">
    <form action="" method="post">
        <h3>Welcome Back!</h3>
        <!-- Email Input -->
        <input type="email" name="email" required maxlength="50" placeholder="Enter your email" class="box">
        <!-- Password Input -->
        <input type="password" name="pass" required maxlength="20" placeholder="Enter your password" class="box">
        
        <!-- Link to the registration page -->
        <p>Don't have an account? <a href="register.html">Register new</a></p>

        <!-- Submit Button -->
        <input type="submit" value="Login now" name="submit" class="btn">
    </form>

    <!-- Display warning message if login fails -->
    <?php
    if (!empty($warning_msg)) {
        foreach ($warning_msg as $msg) {
            echo '<div class="warning-msg">' . $msg . '</div>';
        }
    }
    ?>
</section>
<!-- Login form section ends -->

<!-- External JavaScript (SweetAlert) for notifications -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<?php include 'components/footer.php'; ?>

<!-- Custom JavaScript file -->
<script src="js/script.js"></script>

<?php include 'components/message.php'; ?>

</body>
</html>