<?php
// Ensure $user_id is defined to avoid undefined variable warning
$user_id = isset($_COOKIE['user_id']) ? $_COOKIE['user_id'] : '';

// header section starts
?>

<header class="header">
    <nav class="navbar nav-1">
        <section class="flex">
            <a href="home.php" class="logo"><i class="fas fa-house"></i>House Hunt India</a>
            <ul>
                <li><a href="post_property.php">post property<i class="fas fa-paper-plane"></i></a></li>
            </ul>
        </section>
    </nav>

    <nav class="navbar nav-2">
        <section class="flex">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div class="menu">
                <ul>
                    <li><a href="#">Profile<i class="fas fa-angle-down"></i></a>
                        <ul>
                            <li><a href="dashboard.php">dashboard</a></li>
                            <li><a href="my_listings.php">my listings</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Buy<i class="fas fa-angle-down"></i></a>
                        <ul>
                            <li><a href="search.php">filter search</a></li>
                            <li><a href="listings.php">all listings</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Rent<i class="fas fa-angle-down"></i></a>
                        <ul>
                            <li><a href="search.php">filter search</a></li>
                            <li><a href="listings.php">all listings</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Sell<i class="fas fa-angle-down"></i></a>
                        <ul>
                            <li><a href="post_property.php">Post a property</a></li>
                        </ul>
                    </li>
                    <li><a href="#">help<i class="fas fa-angle-down"></i></a>
                        <ul>
                            <li><a href="about.php">about us</a></li>
                            <li><a href="contact.php">contact us</a></li>
                            <li><a href="contact.php#faq">FAQ</a></li>
                        </ul>
                    </li>
                </ul>
            </div>

            <ul>
                <li><a href="saved.php">saved <i class="far fa-heart"></i></a></li>
                <li><a href="#">account <i class="fas fa-angle-down"></i></a>
                    <ul>
                        <?php if ($user_id == '') { ?>
                            <li><a href="login.php">login now</a></li>
                            <li><a href="register.php">register new</a></li>
                        <?php } else { ?>
                            <li><a href="update.php">update profile</a></li>
                            <li><a href="components/user_logout.php" onclick="return confirm('logout from this website?');">logout</a></li>
                        <?php } ?>
                    </ul>
                </li>
            </ul>
        </section>
    </nav>
</header>

<!-- header section ends -->
